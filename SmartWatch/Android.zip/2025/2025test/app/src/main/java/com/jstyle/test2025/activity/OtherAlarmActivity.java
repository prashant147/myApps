package com.jstyle.test2025.activity;

import android.os.Bundle;

import com.jstyle.test2025.R;

public class OtherAlarmActivity extends BaseActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_alarm);
    }
}
