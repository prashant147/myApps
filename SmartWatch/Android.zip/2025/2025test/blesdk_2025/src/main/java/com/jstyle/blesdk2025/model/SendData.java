package com.jstyle.blesdk2025.model;

/**
 * Created by Administrator on 2018/4/8.
 */

public class SendData {
}
