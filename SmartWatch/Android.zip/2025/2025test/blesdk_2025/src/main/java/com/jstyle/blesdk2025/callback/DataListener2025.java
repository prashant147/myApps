package com.jstyle.blesdk2025.callback;

import java.util.Map;

/**
 * Created by Administrator on 2018/4/10.
 */

public interface DataListener2025 {
     void dataCallback(Map<String, Object> maps);
     void dataCallback(byte[] value);

}
