package lecho.lib.hellocharts.gesture;

/**
 * Enum used to inform chart in what type of container it exists.
 * 
 */
public enum ContainerScrollType {
	HORIZONTAL, VERTICAL,HORIZONTAL_IN_ScrollView
}
