package lecho.lib.hellocharts;

import lecho.lib.hellocharts.animation.ChartAnimationListener;

public class DummyChartAnimationListener implements ChartAnimationListener {

	@Override
	public void onAnimationStarted() {
		// do nothing

	}

	@Override
	public void onAnimationFinished() {
		// do nothing

	}

}
