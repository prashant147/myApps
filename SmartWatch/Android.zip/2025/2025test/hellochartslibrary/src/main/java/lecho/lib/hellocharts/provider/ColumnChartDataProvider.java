package lecho.lib.hellocharts.provider;

import lecho.lib.hellocharts.model.ColumnChartData;

public interface ColumnChartDataProvider {

	public ColumnChartData getColumnChartData();

	public void setColumnChartData(ColumnChartData data);

}
